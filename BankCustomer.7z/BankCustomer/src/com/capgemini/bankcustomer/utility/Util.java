package com.capgemini.bankcustomer.utility;


import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Util {
public static EntityManager getEntityManager() {
		
		return Persistence.createEntityManagerFactory("BankCustomer").createEntityManager();
	}
	
}
